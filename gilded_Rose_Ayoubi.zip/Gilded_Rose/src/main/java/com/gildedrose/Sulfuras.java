package com.gildedrose;

/*	- "Sulfuras", being a legendary item, never has to be sold or decreases in Quality*/
class Sulfuras implements GildedRoseltem {
	  
		@Override
		public void updateQuality() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void decrementSellIn() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean hasExpired() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean expiresBy(int expiryTime) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void decrementQuality() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void incrementQuality() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setNoQuality() {
			// TODO Auto-generated method stub
			
		}
	}

	
	



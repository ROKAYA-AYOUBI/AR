package com.gildedrose;

/* This type of Conjured article: their quality deteriorates twice as fast as usual. */
public class Conjured extends GRCATEGORY{

	Conjured(Item item) {
		super(item);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void updateQuality() {
		// TODO Auto-generated method stub
		    decrementQuality();

	        decrementSellIn();

	        if (hasExpired()) {
	            decrementQuality();
	        }
	}

	

}

package com.gildedrose;

/*Each item is characterized 
 * by a name, 
 * a quality: quality that indicates its intrinsic value,
 *  and a deadline: according to the number of days prior to which the item is to be sold
 * **/

public class Item {

    public String name;

    public int sellIn;

    public int quality;

    public Item(String name, int sellIn, int quality) {
        this.name = name;
        this.sellIn = sellIn;
        this.quality = quality;
    }

   @Override
   public String toString() {
        return this.name + ", " + this.sellIn + ", " + this.quality;
    }
}

package com.gildedrose;

/*"Backstage passes", like aged brie, increases in Quality as its SellIn value approaches;
Quality increases by 2 when there are 10 days or less and by 3 when there are 5 days or less but
Quality drops to 0 after the concert*/
public class BackstagePasses extends GRCATEGORY{

	BackstagePasses(Item item) {
		super(item);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void updateQuality() {
		// TODO Auto-generated method stub
		 incrementQuality();
	        if (expiresBy(11)) {
	            incrementQuality();
	        }

	        if (expiresBy(6)) {
	            incrementQuality();
	        }

	        decrementSellIn();

	        if (hasExpired()) {
	            setNoQuality();
	    }
	

	}
}

package com.gildedrose;

/*	"Aged Brie"  increases Quality as it ages */
public class AgedBrie extends GRCATEGORY {

	public AgedBrie(Item item) {
		// TODO Auto-generated constructor stub
		super(item);
	}
	
	@Override
	public void updateQuality() {

		    incrementQuality();

	        decrementSellIn();
            /* If the article is expressed that is to say Sellit=0, in this case we increase once again the quality*/
	        if (hasExpired()) {
	            incrementQuality();
	        }
	}


}

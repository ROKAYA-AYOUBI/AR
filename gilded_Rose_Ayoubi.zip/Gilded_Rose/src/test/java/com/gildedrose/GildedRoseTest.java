package com.gildedrose;

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public class GildedRoseTest {
	
	/* This function allows to test whether the product quality Aged Brie ( example Cheese)
     *  increases well after the sale date is decremented 
     */
	    @Test
	    public void qualityIncreasesOverTimeForCheese() {
	    	/* Reminder: /*  "Aged Brie" actually increases in Quality the older it gets: Example Cheese */
	         /*Our article is: 
	         * Name: Aged Brie
	         * Deadline Sale: 12
	         * Quality: 3 % Quality: 3
	         */
		    Item item = new Item("Aged Brie", 12, 3);
	        GildedRose gildedRose = new GildedRose(new Item[]{item});
	        /* after calling this updateQuality function of the Gildedrose2 class
	         * for the Aged Brie item: the quality should be incremented by 
	         * 1 ( 3+1=4 )
	         */
	        gildedRose.updateQuality();
	        /*
	         * assertEquals this function of Junit , allows to test if the product quality is good 
	         * incremented to 4 after calling gildedRose.updateQuality();
	         */
	        assertEquals(4, item.quality);
	        /* 
	         * it is the same for the following other inscructions 
	         * after the apple to the updateQuality function, the quality increases by 1       
	         **/
	        gildedRose.updateQuality();
	        assertEquals(5, item.quality);
	        gildedRose.updateQuality();
	        assertEquals(6, item.quality);
	        gildedRose.updateQuality();
	        assertEquals(7, item.quality);
	        /*
	         * The test is OK
	         */
	    }

	    /* This function allows to test when we have an article 'Conjured', we will notice 
	      *  that the quality of the products is quickly reduced if the product has expired 
	      *  of their sale =0 
	      */
	    @Test
	    public void qualityDecreasesMoreQuicklyAfterSellByDateForUnknownThings() {
	    	/* � "Conjured" items degrade in Quality twice as fast as normal items */
	         /*Our article is: 
	         * Name: foo: Article 
	         * Deadline Sale: 1
	         * Quality: 6 % Quality: 6
	         */
	        Item item = new Item("foo", 1, 6);
	        GildedRose gildedRose = new GildedRose(new Item[]{item});
	        /* after calling this updateQuality function of the Gildedrose class
	         * for the "Conjured" type item: the quality must normally be decreed by 1
	         *  ( 6-1=5)
	         * because the limited date of sale would be 0 
	         */
	        gildedRose.updateQuality();
	        /*
	         * assertEquals allows to test if the product quality is good 
	         * decremented to 5 after calling gildedRose.updateQuality();
	         */
	        assertEquals(5, item.quality);
	        /* after calling this updateQuality function of the Gildedrose class
	         * for the "Conjured" type item: the quality must normally be decreed by 2
	         *  ( 5-2=3)
	         * because the limited date of sale would be 0 
	         */
	        gildedRose.updateQuality();
	        /*
	         * assertEquals allows to test if the product quality is good 
	         * decremented to 3 after calling gildedRose.updateQuality();
	         */
	        assertEquals(3, item.quality);
	        /* it is the same for the following other inscructions 
	         * after the apple to the updateQuality function, the quality is decremnete of 2
	         * because the limited date of sale would be 0          
	         * **/
	        gildedRose.updateQuality();
	        assertEquals(1, item.quality);
	        gildedRose.updateQuality();
	        assertEquals(0, item.quality);
	    }

	    /* Normally the quality of a product should never be negative */
	    /* This function allows to test the same functionality for a second time
	    * of this test method qualityDecreasesMoreQuicklyAfterSellByDateForUnknownThings
	    * by adding another quality value test after 0
	    * if it will decrease again so that it is a negative value, or
	    * it will remain on the value 0 ( positive).
	    */
	    @Test
	    public void qualityDecreasesOverTimeForUnknownThings() {
	        Item item = new Item("foo", 2, 3);
	        GildedRose gildedRose = new GildedRose(new Item[]{item});
	        gildedRose.updateQuality();
	        assertEquals(2, item.quality);
	        gildedRose.updateQuality();
	        assertEquals(1, item.quality);
	        gildedRose.updateQuality();
	        assertEquals(0, item.quality);
	        /*
	         * we notice that the quality is well decremented up to 0
	         */
	        gildedRose.updateQuality();
	        /*
	         * the quality will always be equal to 0, because the quality must not be negative
	         */
	        assertEquals(0, item.quality);
	    }

	    /*
	     * This function allows you to test whether the value of Sellin ( sales deadline )
	     * is well decreed by 1 after each end of day
	     * for several types of articles ( Backstage,Aged Brie,Conjured, not recognized article )
	     */
	    @Test
	    public void sellInDecreasesEveryDayForMostItems() {
	        sellInDecreasesEveryDayForItem(new Item("foo", 2, 0));
	        sellInDecreasesEveryDayForItem(new Item("Backstage passes to a TAFKAL80ETC concert", 2, 0));
	        sellInDecreasesEveryDayForItem(new Item("Aged Brie", 2, 0));
	        sellInDecreasesEveryDayForItem(new Item("Conjured Mana Cake", 2, 0));
	    }
	    
	    /* 
	     * This function called in the test function sellInDecreasesEveryDayForMostItems
	     * for each type of article, allows to do a test after the call 
	     * to the updateQuality function, we will notice that Sellin is decremented by 1
	     */
	    private void sellInDecreasesEveryDayForItem(Item item) {
	        GildedRose gildedRose = new GildedRose(new Item[]{item});

	        gildedRose.updateQuality();
	        assertEquals(1, item.sellIn);
	        gildedRose.updateQuality();
	        assertEquals(0, item.sellIn);
	        gildedRose.updateQuality();
	        assertEquals(-1, item.sellIn);
	    }
	    

	    /*
	    * This function is used to test sulphas
	    * if the application complies with this management rule:
	    * "Sulfuras", being a legendary item, never has to be sold or decreased in Quality"
	    * So after calling updateQuality,
	    * the value of sellIn ( sale deadline ) must never be decremented
	    * since it will never be sold ("Sulfuras", never has to be sold )
	    * This is the case after the call for the updateQuality method
	    * we note that the value of item.sellIn is always equal to 2
	    */
	    @Test
	    public void sulfurasNeverAges() {
	        Item item = new Item("Sulfuras, Hand of Ragnaros", 2, 0);
	        GildedRose gildedRose = new GildedRose(new Item[]{item});

	        gildedRose.updateQuality();
	        assertEquals(2, item.sellIn);
	        gildedRose.updateQuality();
	        assertEquals(2, item.sellIn);
	        gildedRose.updateQuality();
	        assertEquals(2, item.sellIn);
	    }

	  
}
